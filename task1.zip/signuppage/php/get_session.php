<?php
require "predis/autoload.php";
$redis = new Predis\Client();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['TOKEN'])) {
        $token = $_POST['TOKEN'];
        // echo $token;
        if($redis){
            $data = $redis->hmget($token,['email','login','name','age','dob','ph']);
            echo json_encode($data);
        }else{
            echo  "Redis Not connected";
        }
    }
}
?>