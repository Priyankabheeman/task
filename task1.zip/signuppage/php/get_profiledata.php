<?php
require 'vendor/autoload.php';
$mongoURI = "mongodb://localhost:27017";
$dbName = "profiles";
$collectionName = "signup";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['TOKEN'])) {
        $token = $_POST['TOKEN'];
try {

    $client = new MongoDB\Client($mongoURI);
    $db = $client->$dbName;
    $collection = $db->$collectionName;

    require "predis/autoload.php";
    $redis = new Predis\Client();
    $redisemail = $redis->hmget($token,'email');
    echo $redisemail[0];
    $email = $redisemail[0];


    if (!empty($email)) {

        $document = $collection->findOne(["email" => $email]);

        if (!empty($document)) {
            $age = $document['age'];
            $dob = $document['dob'];
            $contact = $document['contact'];
            echo $age .''. $dob .''. $contact .'';
            $redis->hmset($token,'age', $age,'dob',$dob,'ph',$contact);
        } else {
            echo "No profile found for the email: $email";
        }
    } else {
        echo "Email is missing!";
    }
} catch (MongoDB\Exception\Exception $e) {
    echo "Error: " . $e->getMessage();
}
    }}
?>