<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
  if(isset($_POST['email'])) {
    $email = $_POST['email'];
    // echo "email: " . $email . "\n";
  }
  if(isset($_POST['pass'])) {
    $pass = $_POST['pass'];
    // echo "pass: " . $pass ."\n";
  }

  $conn = mysqli_connect("localhost", "priya", "1234", "interntask");
  if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "SELECT `email`, `pass`,`name` FROM `userdetails` WHERE `email` = '$email'";
  $result = mysqli_query($conn, $sql);
  if (!$result) {
      die("Error in SQL query: " . mysqli_error($conn));
  }
  $row = mysqli_fetch_assoc($result);
  $getemail = $row['email'];
  $getpass = $row['pass'];
  $getname = $row['name'];

  //echo "getname ". $getemail ."\n";
  //echo "getpass ".$getpass ."\n";
  //echo "getname ".$getname ."\n";
  mysqli_close($conn);

        
  require "predis/autoload.php";
  $redis = new Predis\Client();
  if ($email=="" && $pass=="")
  {
    $redis->hmset('data','login','0');
  }
  else {
    if($email==$getemail && $pass==$getpass)
    {
      $timestamp = time();
      $data = $getname . '|' . $timestamp;
      $authToken = base64_encode($data);
      echo $authToken;
      $redis->hmset($authToken,'email',"$getemail",'login',"1",'name',"$getname");
      
    }
    else
    {
      $redis->hmset('data','login',"0");
    }
  }
}
else {
  echo "error \n";
}