document.getElementById('loginbtn').addEventListener('click', function(event) {
  var email = document.getElementById("login-email").value;
    var pass = document.getElementById("login-password").value;
    console.log(email);
    console.log(pass);
    if(email.toString()==="" || pass.toString()==="")
    {
      alert("Enter password");
    }
    else
    {
      // alert("login");

   //AJAX request
 var xhr = new XMLHttpRequest();
 xhr.open('POST', './php/login.php', true);
 xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
//  xhr.send('email=' + encodeURIComponent(email) + '&pass=' + encodeURIComponent(pass));
 xhr.onreadystatechange = function () {
   if (xhr.readyState === XMLHttpRequest.DONE) {
     if (xhr.status === 200) {
       console.log('RES:'+xhr.responseText); // Print the response from PHP
       localStorage.setItem('authToken', xhr.responseText);
      //  console.log(localStorage.getItem('authToken'));
     } else {
       console.error('Error:', xhr.status);
     }
   }
 };
 // Combine both sets of data and send them together
 xhr.send('email=' + encodeURIComponent(email) + '&pass=' + encodeURIComponent(pass));
 
 setTimeout( ()=>{
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "./php/get_session.php", true);
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr.onreadystatechange = function () {
    if (xhr.readyState === XMLHttpRequest.DONE) {
      if (xhr.status === 200) {
        var sessionData = JSON.parse(xhr.responseText); 
        //console.log(sessionData[2]);
        if(sessionData[1]==1)
          {
            window.location.href='http://localhost/signuppage/profile.html';
          }
         delete sessionData;
    }}
};
xhr.send('TOKEN=' + encodeURIComponent(localStorage.getItem('authToken')));
}, 500);
    }
});
