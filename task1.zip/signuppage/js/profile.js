var sessionData;
function openeditbox(){
  document.getElementById("container-form").style.display = 'block';
  document.getElementById("container-edit").style.display = 'none';
}

function openinfobox(){
  document.getElementById("container-form").style.display = 'none';
  document.getElementById("container-edit").style.display = 'block';

}
function profilebtnclk() {
  document.getElementById("container-form").style.display = 'block';
  document.getElementById("container-edit").style.display = 'none';   
  var xhr1 = new XMLHttpRequest();
  xhr1.open("POST", "./php/get_profiledata.php", true);
  xhr1.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  xhr1.onreadystatechange = function () {
    if (xhr1.readyState === XMLHttpRequest.DONE) {
      if (xhr1.status === 200) {
      }}
  };
  xhr1.send('TOKEN=' + encodeURIComponent(localStorage.getItem('authToken')));

setTimeout(() => { 
var xhr = new XMLHttpRequest();
xhr.open("POST", "./php/get_session.php", true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xhr.onreadystatechange = function () {
  if (xhr.readyState === XMLHttpRequest.DONE) {
    if (xhr.status === 200) {
        var sessionData1 = JSON.parse(xhr.responseText); 
        document.getElementById("h-name").textContent = sessionData1[2];
        document.getElementById("h-age").textContent = sessionData1[3];
        document.getElementById("h-dob").textContent = sessionData1[4];
        document.getElementById("h-ph").textContent = sessionData1[5];
    }}
};
xhr.send('TOKEN=' + encodeURIComponent(localStorage.getItem('authToken')));
}, 500);
}
function logoutbtnclk() {
    window.location.href = 'http://localhost/signuppage/index.html';
    localStorage.removeItem('authToken');
}
function load(){
  document.getElementById("container-form").style.display = 'none';
    document.getElementById("container-edit").style.display = 'none';

var xhr = new XMLHttpRequest();
xhr.open("POST", "./php/get_session.php", true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xhr.onreadystatechange = function () {
  if (xhr.readyState === XMLHttpRequest.DONE) {
    if (xhr.status === 200) {
      // console.log(xhr.responseText); 
      var sessionData1 = JSON.parse(xhr.responseText);
      //console.log(sessionData1);
        document.getElementById("heading").textContent="Welcome "+sessionData1[2];
    } else {
      console.error('Error:', xhr.status);
    }
  }
};
xhr.send('TOKEN=' + encodeURIComponent(localStorage.getItem('authToken')));
}

document.getElementById('updatebtn').addEventListener('click', function(event) {
    event.preventDefault();
    var age = document.getElementById("update-age").value;
    var dob = document.getElementById("update-dob").value;
    var ph = document.getElementById("update-ph").value;
  
 const xhr = new XMLHttpRequest();
 xhr.open('POST', './php/profile.php', true);
 xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
 xhr.onreadystatechange = function () {
   if (xhr.readyState === XMLHttpRequest.DONE) {
     if (xhr.status === 200) {
       //console.log(xhr.responseText); 
     } else {
       console.error('Error:', xhr.status);
     }
   }
 };

 xhr.send('age=' + encodeURIComponent(age) + '&dob=' + encodeURIComponent(dob) + '&ph=' + encodeURIComponent(ph) + '&TOKEN=' + encodeURIComponent(localStorage.getItem('authToken')));
setTimeout(() => {  profilebtnclk(); }, 1000);

});